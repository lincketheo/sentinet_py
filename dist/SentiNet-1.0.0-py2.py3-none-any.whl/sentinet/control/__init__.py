from sentinet.control import StateMachine
